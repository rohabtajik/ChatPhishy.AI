# Import necessary libraries
import streamlit as st
import pandas as pd
import numpy as np
import re
import string
import pickle
import email
from email.parser import Parser
from bs4 import BeautifulSoup
import matplotlib.pyplot as plt
import seaborn as sns
import time
import os
 
# Set page configuration
st.set_page_config(
    page_title="Phishing Email Detector",
    page_icon="🔍",
    layout="wide"
)
 
# Simple preprocessing function (no NLTK dependency)
def simple_preprocess_text(text):
    """Preprocess text without NLTK data dependencies"""
    # Handle empty or None text
    if text is None or text == "":
        return ""
   
    # Convert to string if necessary
    if not isinstance(text, str):
        text = str(text)
   
    # Convert to lowercase
    text = text.lower()
   
    # Remove URLs
    text = re.sub(r'http\S+|www\S+|https\S+', '', text)
   
    # Remove emails
    text = re.sub(r'\S+@\S+', '', text)
   
    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
   
    # Remove numbers
    text = re.sub(r'\d+', '', text)
   
    # Simple tokenization (split by whitespace)
    tokens = text.split()
   
    # Remove short words
    tokens = [word for word in tokens if len(word) > 2]
   
    # Join back into text
    processed_text = ' '.join(tokens)
   
    return processed_text
 
# Function to extract text from email content
def extract_email_text(email_content):
    try:
        # Parse the email content
        email_message = email.message_from_string(email_content)
       
        # Extract the subject
        subject = email_message.get('Subject', '')
       
        # Initialize body text
        body_text = ""
       
        # Handle multipart emails
        if email_message.is_multipart():
            for part in email_message.walk():
                content_type = part.get_content_type()
                content_disposition = str(part.get('Content-Disposition'))
               
                # Skip attachments
                if 'attachment' in content_disposition:
                    continue
               
                # Get the email body
                if content_type == 'text/plain' or content_type == 'text/html':
                    body = part.get_payload(decode=True)
                    if body:
                        # Convert bytes to string if necessary
                        if isinstance(body, bytes):
                            body = body.decode(errors='ignore')
                       
                        # Clean HTML content if present
                        if content_type == 'text/html':
                            body = BeautifulSoup(body, 'html.parser').get_text()
                       
                        body_text += body
        else:
            # Handle non-multipart emails
            content_type = email_message.get_content_type()
            body = email_message.get_payload(decode=True)
           
            if body:
                # Convert bytes to string if necessary
                if isinstance(body, bytes):
                    body = body.decode(errors='ignore')
               
                # Clean HTML content if present
                if content_type == 'text/html':
                    body = BeautifulSoup(body, 'html.parser').get_text()
               
                body_text = body
       
        # Combine subject and body
        full_text = subject + " " + body_text
        return full_text
   
    except Exception as e:
        return email_content  # Return original content if parsing fails
 
# Function to extract features from emails
def extract_features(email_content):
    features = {}
   
    # Basic text features
    text = extract_email_text(email_content)
    processed_text = simple_preprocess_text(text)
    features['processed_text'] = processed_text
   
    # Count of URLs
    url_pattern = r'http\S+|www\S+|https\S+'
    features['url_count'] = len(re.findall(url_pattern, text.lower()))
   
    # Check for suspicious words
    suspicious_words = ['urgent', 'alert', 'verify', 'account', 'bank', 'password',
                        'confirm', 'update', 'security', 'login', 'click', 'access']
   
    for word in suspicious_words:
        features[f'contains_{word}'] = 1 if word in text.lower() else 0
   
    # Email length
    features['email_length'] = len(text)
   
    # Count of HTML tags (if HTML content)
    html_tag_pattern = r'<[^>]+>'
    features['html_tag_count'] = len(re.findall(html_tag_pattern, text))
   
    # Count of exclamation marks
    features['exclamation_count'] = text.count('!')
   
    # Check for common phishing domains (simplified)
    suspicious_domains = ['secure', 'banking', 'login', 'verify', 'update']
    email_domains_pattern = r'@(\w+)\.'
    domains = re.findall(email_domains_pattern, text.lower())
   
    features['suspicious_domain'] = 0
    for domain in domains:
        if any(susp in domain for susp in suspicious_domains):
            features['suspicious_domain'] = 1
            break
   
    return features, text
 
# Load the saved model
@st.cache_resource
def load_model():
    try:
        with open('phishing_detection_model.pkl', 'rb') as file:
            model_data = pickle.load(file)
        return model_data
    except Exception as e:
        st.warning(f"Could not load saved model: {str(e)}. Using fallback classification.")
        return None
 
# Function to classify an email
def classify_email(email_content, model_data=None):
    # Extract features
    features, original_text = extract_features(email_content)
   
    if model_data is None:
        # Fallback: Use rule-based classification if model not available
        phishing_score = 0
       
        # Check suspicious words
        for word in ['urgent', 'alert', 'verify', 'account', 'bank', 'password',
                    'confirm', 'update', 'security', 'login', 'click', 'access']:
            if features.get(f'contains_{word}', 0) == 1:
                phishing_score += 1
       
        # Check URL count
        if features.get('url_count', 0) > 0:
            phishing_score += features.get('url_count', 0)
       
        # Check suspicious domain
        if features.get('suspicious_domain', 0) == 1:
            phishing_score += 2
       
        # Check exclamation marks
        if features.get('exclamation_count', 0) > 2:
            phishing_score += 1
       
        # Determine prediction based on score threshold
        prediction = 1 if phishing_score >= 3 else 0
        probability = min(phishing_score / 10, 0.99) if prediction == 1 else max(1 - (phishing_score / 10), 0.01)
       
        return prediction, probability, original_text, features
   
    else:
        # Use ML model for classification
        processed_text = features.pop('processed_text')
       
        # Transform text using TF-IDF
        tfidf_vectorizer = model_data['tfidf_vectorizer']
        text_features = tfidf_vectorizer.transform([processed_text])
       
        # Create DataFrame for other features
        feature_names = model_data['features']
        feature_values = []
       
        for feature in feature_names:
            feature_values.append(features.get(feature, 0))
       
        features_df = pd.DataFrame([feature_values], columns=feature_names)
       
        # Combine features
        combined_features = np.hstack((text_features.toarray(), features_df.values))
       
        # Make prediction
        model = model_data['model']
        prediction = model.predict(combined_features)[0]
        probability = model.predict_proba(combined_features)[0][1]  # Probability of being phishing
       
        return prediction, probability, original_text, features
 
# Function to highlight suspicious words in text
def highlight_suspicious_words(text):
    suspicious_words = ['urgent', 'alert', 'verify', 'account', 'bank', 'password',
                       'confirm', 'update', 'security', 'login', 'click', 'access',
                       'verify', 'suspend', 'restrict', 'authenticate']
   
    highlighted_text = text
    for word in suspicious_words:
        pattern = re.compile(r'\b' + word + r'\b', re.IGNORECASE)
        highlighted_text = pattern.sub(f'<span style="background-color: yellow; color: red; font-weight: bold;">{word.upper()}</span>', highlighted_text)
   
    return highlighted_text
 
# Function to display phishing indicators
def display_phishing_indicators(features):
    st.subheader("Phishing Indicators")
   
    indicators = []
   
    # Check suspicious words
    suspicious_words = ['urgent', 'alert', 'verify', 'account', 'bank', 'password',
                       'confirm', 'update', 'security', 'login', 'click', 'access']
   
    for word in suspicious_words:
        if features.get(f'contains_{word}', 0) == 1:
            indicators.append(f"Contains suspicious word: '{word}'")
   
    # Check URL count
    url_count = features.get('url_count', 0)
    if url_count > 0:
        indicators.append(f"Contains {url_count} URLs")
   
    # Check suspicious domain
    if features.get('suspicious_domain', 0) == 1:
        indicators.append("Contains suspicious domain")
   
    # Check exclamation marks
    exclamation_count = features.get('exclamation_count', 0)
    if exclamation_count > 2:
        indicators.append(f"Contains {exclamation_count} exclamation marks")
   
    # Display indicators
    if not indicators:
        st.info("No significant phishing indicators found.")
    else:
        for indicator in indicators:
            st.warning(f"⚠️ {indicator}")
 
# Function to create a dashboard layout
def create_dashboard():
    st.title("📧 Phishing Email Detector")
   
    # Create a single tab
    tabs = st.tabs(["Email Analysis"])
   
    # Email Analysis tab
    with tabs[0]:
        st.markdown("### Enter the email content to analyze:")
       
        # Input options
        input_method = st.radio("Input method:", ["Enter text", "Upload .eml file"])
       
        email_content = ""
       
        if input_method == "Enter text":
            email_content = st.text_area("", height=300, placeholder="Paste the email content (including headers if available)")
        else:
            uploaded_file = st.file_uploader("Upload an .eml file", type=["eml", "txt"])
            if uploaded_file is not None:
                email_content = uploaded_file.getvalue().decode("utf-8", errors="ignore")
                st.text_area("Email content", email_content, height=200)
       
        # Analysis button
        analyze_button = st.button("Analyze Email")
       
        if analyze_button and email_content:
            with st.spinner("Analyzing email..."):
                # Add progress bar for visual feedback
                progress_bar = st.progress(0)
                for i in range(100):
                    time.sleep(0.01)
                    progress_bar.progress(i + 1)
               
                # Load model
                model_data = load_model()
               
                # Get prediction
                prediction, probability, original_text, features = classify_email(email_content, model_data)
               
                # Display results
                st.markdown("### Analysis Results")
               
                col1, col2 = st.columns(2)
               
                with col1:
                    if prediction == 1:
                        st.error("### ⚠️ Phishing Email Detected!")
                        st.markdown(f"Confidence: **{probability*100:.2f}%**")
                    else:
                        st.success("### ✅ Legitimate Email")
                        st.markdown(f"Confidence: **{(1-probability)*100:.2f}%**")
               
                with col2:
                    # Create gauge chart for probability
                    fig, ax = plt.subplots(figsize=(4, 0.8))
                    ax.barh(0, probability, color='red', height=0.2)
                    ax.barh(0, 1-probability, left=probability, color='green', height=0.2)
                    ax.set_xlim(0, 1)
                    ax.set_ylim(-0.5, 0.5)
                    ax.set_yticks([])
                    ax.set_xticks([0, 0.25, 0.5, 0.75, 1])
                    ax.set_xticklabels(['0%', '25%', '50%', '75%', '100%'])
                    ax.axvline(x=0.5, color='grey', linestyle='--', alpha=0.5)
                   
                    if prediction == 1:
                        ax.text(probability/2, 0, "Phishing", ha='center', va='center', color='white', fontweight='bold')
                        ax.text((1+probability)/2, 0, "Legitimate", ha='center', va='center', color='white')
                    else:
                        ax.text(probability/2, 0, "Phishing", ha='center', va='center', color='white')
                        ax.text((1+probability)/2, 0, "Legitimate", ha='center', va='center', color='white', fontweight='bold')
                   
                    st.pyplot(fig)
               
                # Display email with highlighted suspicious words
                st.markdown("### Email Content Analysis")
               
                highlighted_text = highlight_suspicious_words(original_text)
               
                # Display highlighted text
                st.markdown(highlighted_text, unsafe_allow_html=True)
               
                # Display phishing indicators if prediction is phishing
                if prediction == 1:
                    display_phishing_indicators(features)
               
                # Warning or recommendation
                st.markdown("---")
                if prediction == 1:
                    st.warning("""
                    ### Recommendation
                    - Do not click on any links in this email
                    - Do not download any attachments
                    - Do not reply with any personal information
                    - Report this email to your IT department or email provider
                    """)
                else:
                    st.info("""
                    ### Information
                    This email appears to be legitimate, but always exercise caution with emails requesting sensitive information.
                    """)
 
# Run the app
def main():
    create_dashboard()
 
if __name__ == "__main__":
    main()
 